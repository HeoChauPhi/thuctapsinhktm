<!-- pagination -->
<div class="pagination">
	<?php startedwp_pagination(); ?>
</div>
<!-- /pagination -->
