jQuery(document).ready(function($) {
	// my custom js
  /*pathArray = location.href.split( '/' );
  protocol = pathArray[0];
  host = pathArray[2];
  url = protocol + '//' + host;
  $('.support-online-widget .supporter-skype img').attr('src', url + '/wp-content/themes/started/custom/framework-assets/images/skype-master.png');*/

  $(".block-search .search").hide();
  $(".block-search .toggle-search").click(function(){
    $(this).toggleClass("open");
    $(this).toggleClass("close");
    $(".block-search .search").slideToggle();
  });
});
