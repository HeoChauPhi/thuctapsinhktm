		</div>
		<div class="vp-js-bind-loader vp-field-loader vp-hide"><img src="<?php VP_Util_Res::img_out('ajax-loader.gif', ''); ?>" /></div>
		<div class="validation-msgs"><ul></ul></div>
	</div>
</div>